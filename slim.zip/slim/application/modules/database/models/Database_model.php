<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Database_model extends CI_Model {

    public function get_all_databases($keyword = null) {
        if($keyword) {
            $this->db->like('database_name', $keyword);
        }
        return $this->db->get('tbl_database')->result_array();
    }

    public function insert_database($data) {
        return $this->db->insert('tbl_database', $data);
    }

    public function update_database($id, $data) {
        $this->db->where('database_id', $id);
        return $this->db->update('tbl_database', $data);
    }

    public function delete_database($id) {
        $this->db->where('database_id', $id);
        return $this->db->delete('tbl_database');
    }
	
	public function check_duplicate_database($name, $id = null) {
        // Cek apakah ada database_name yang sama
        $this->db->where('database_name', $name);

        // Jika ID ada (sedang Edit), kecualikan data milik ID tersebut
        // Agar saat save tanpa ganti nama, tidak dianggap error
        if($id) {
            $this->db->where('database_id !=', $id);
        }

        $query = $this->db->get('tbl_database');

        // Kembalikan TRUE jika data ditemukan (berarti duplikat), FALSE jika aman
        return $query->num_rows() > 0;
    }
	
	// Hitung Total Data (Untuk menentukan jumlah halaman)
    public function count_all_databases($keyword = null) {
        if($keyword) {
            $this->db->like('database_name', $keyword);
        }
        return $this->db->count_all_results('tbl_database');
    }

    // Ambil Data dengan Limit (Untuk isi tabel per halaman)
    public function get_databases_paginated($limit, $start, $keyword = null) {
        if($keyword) {
            $this->db->like('database_name', $keyword);
        }
        // Opsional: Urutkan dari yang terbaru
        $this->db->order_by('database_id', 'ASC'); 
        return $this->db->get('tbl_database', $limit, $start)->result_array();
    }
}