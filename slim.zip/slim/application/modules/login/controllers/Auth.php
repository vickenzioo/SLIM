<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Auth_model');
        $this->load->library('form_validation');
        $this->load->library('session'); 
    }

    public function index() {
        if ($this->session->userdata('email')) {
            redirect('dashboard');
        }

        // Ambil pesan error dari session lalu hapus
        $data['pesan_error'] = $this->session->userdata('message');
        if ($this->session->userdata('message')) {
            $this->session->unset_userdata('message');
        }
        
        $this->load->view('login', $data);
    }

    public function process_login() {
        // Cek apakah user masuk kesini tanpa klik tombol Login (misal: Refresh halaman/Ketik URL)
        if ($this->input->method() !== 'post') {
            redirect('auth');
        }

        $this->form_validation->set_rules('email', 'Email', 'required|valid_email', [
            'required' => 'Email wajib diisi!',
            'valid_email' => 'Format email tidak benar!'
        ]);
        $this->form_validation->set_rules('password', 'Password', 'required', [
            'required' => 'Password wajib diisi!'
        ]);

        if ($this->form_validation->run() == FALSE) {
            // Validasi Gagal: Load View lagi agar pesan error muncul
            $data['pesan_error'] = ''; 
            $this->load->view('login', $data); 
        } else {
            $email = $this->security->xss_clean(trim($this->input->post('email', TRUE)));
            $password = $this->security->xss_clean(trim($this->input->post('password'))); 
            
            $user = $this->Auth_model->get_user_by_email($email);

            if ($user) {
                // Cek Password Biasa (Plain Text)
                if ($password == $user['password']) {
                    
                    // -----------------------------------------------------------
                    // UPDATE PENTING: MENYIMPAN NAMA KE SESSION
                    // -----------------------------------------------------------
                    $data = [
                        'user_id'  => $user['id'], 
                        'email'    => $user['email'],
                        'username' => $user['username'] 
                    ];
                    
                    $this->session->set_userdata($data);
                    redirect('dashboard'); 
                    
                } else {
                    // Password Salah
                    $this->session->set_userdata('message', '<div class="alert alert-danger text-center" role="alert">Password salah!</div>');
                    redirect('auth');
                }
            } else {
                // Email Tidak Ditemukan
                $this->session->set_userdata('message', '<div class="alert alert-danger text-center" role="alert">Email tidak terdaftar!</div>');
                redirect('auth');
            }
        }
    }
    
    public function logout() {
        $this->session->unset_userdata('email');
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('username'); // Hapus session username juga
        $this->session->sess_destroy();
        
        $this->session->set_userdata('message', '<div class="alert alert-success text-center" role="alert">Anda telah logout!</div>');
        redirect('auth');
    }
}