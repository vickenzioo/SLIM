<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Operational_Hour_model extends CI_Model {

    public function get_all_operational_hours($keyword = null) {
        if($keyword) {
            $this->db->group_start();
			$this->db->like('start_time', $keyword);
			$this->db->or_like('end_time', $keyword);
			$this->db->or_like('total_hour', $keyword);
			$this->db->group_end();
        }
        return $this->db->get('tbl_operational_hour')->result_array();
    }

    public function insert_operational_hour($data) {
        return $this->db->insert('tbl_operational_hour', $data);
    }

    public function update_operational_hour($id, $data) {
        $this->db->where('operational_hour_id', $id);
        return $this->db->update('tbl_operational_hour', $data);
    }

    public function delete_operational_hour($id) {
        $this->db->where('operational_hour_id', $id);
        return $this->db->delete('tbl_operational_hour');
    }
	
	public function check_duplicate_hour($start_time, $end_time, $id = null) {
        // Cek kondisi 2 kolom harus sama persis (AND)
        $this->db->where('start_time', $start_time);
        $this->db->where('end_time', $end_time);

        // Jika sedang Edit, kecualikan data milik sendiri
        if($id) {
            $this->db->where('operational_hour_id !=', $id);
        }

        $query = $this->db->get('tbl_operational_hour');

        // Kembalikan TRUE jika ada data kembar
        return $query->num_rows() > 0;
    }
	
	public function count_all_operational_hours($keyword = null) {
        if($keyword) {
            $this->db->group_start(); // Kurung buka query (agar logika OR tidak bocor)
            $this->db->like('start_time', $keyword);
            $this->db->or_like('end_time', $keyword);
			$this->db->or_like('total_hour', $keyword);
            $this->db->group_end(); // Kurung tutup
        }
        return $this->db->count_all_results('tbl_operational_hour');
    }

    // 2. Fungsi Ambil Data Per Halaman (Ada Limit & Start)
    public function get_operational_hours_paginated($limit, $start, $keyword = null) {
        if($keyword) {
            $this->db->group_start();
            $this->db->like('start_time', $keyword);
            $this->db->or_like('end_time', $keyword);
			$this->db->or_like('total_hour', $keyword);
            $this->db->group_end();
        }
        
        // Urutkan dari yang terbaru (Opsional, tapi disarankan)
        $this->db->order_by('operational_hour_id', 'ASC'); 
        
        // Perhatikan parameter ke-2 dan ke-3: Tabel, Limit, Start
        return $this->db->get('tbl_operational_hour', $limit, $start)->result_array();
    }
}