<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SLIM | Dashboard</title>

  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800;900&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
  <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/1864/1864497.png" type="image/png">
  <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.26.17/dist/sweetalert2.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?= base_url('assets/dist/css/slim/dashboard.css'); ?>">
</head>

<body class="hold-transition sidebar-mini layout-fixed">

<script>
    if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
    }
</script>

<div class="wrapper">

  <nav class="main-header navbar navbar-expand navbar-white navbar-light" style="border-bottom: 3px solid var(--theme-yellow-primary);">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?= base_url('dashboard') ?>" class="nav-link breadcrumb-home">Home</a>
      </li>
    </ul>

    <ul class="navbar-nav ml-auto">
	  <li class="nav-item">
         <a class="nav-link" href="#" role="button" id="darkModeBtn" title="Ganti Mode">
           <i class="fas fa-moon"></i>
         </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-user mr-2"></i>
          <span class="font-weight-bold">
            <?= $this->session->userdata('username') ? $this->session->userdata('username') : 'User'; ?>
          </span>
          <i class="fas fa-caret-down ml-1"></i>
        </a>
        
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <div class="dropdown-divider"></div>
          
          <a href="#" class="dropdown-item">
            <i class="fas fa-user-edit mr-2 text-warning"></i> Edit Profile
          </a>
          
          <div class="dropdown-divider"></div>
          
          <a href="<?= base_url('auth/logout') ?>" class="dropdown-item text-danger" id="logoutLink">
            <i class="fas fa-sign-out-alt mr-2"></i> Logout
          </a>
        </div>
      </li>
    </ul>
  </nav>
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="<?= base_url('dashboard') ?>" class="brand-link">
       <svg width="120" height="40" viewBox="0 0 240 80" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="textGradientSide" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" style="stop-color:#ffffff;stop-opacity:1" /> 
                    <stop offset="100%" style="stop-color:#dcdcdc;stop-opacity:1" />
                </linearGradient>
                <linearGradient id="goldGradientSide" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style="stop-color:#fbc531;stop-opacity:1" />
                    <stop offset="100%" style="stop-color:#e1b12c;stop-opacity:1" />
                </linearGradient>
            </defs>
            <text x="50%" y="55" font-family="'Montserrat', sans-serif" font-weight="900" font-style="italic" font-size="65" fill="url(#textGradientSide)" text-anchor="middle" letter-spacing="-2">SLIM</text>
            <circle cx="195" cy="55" r="6" fill="#fbc531" />
            <path d="M 40 70 L 200 70" stroke="url(#goldGradientSide)" stroke-width="6" stroke-linecap="round" />
        </svg>
    </a>

    <div class="sidebar">

      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          
          <li class="nav-item">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>Dashboard</p>
            </a>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-cubes"></i>
              <p>Apps <i class="right fas fa-angle-left"></i></p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?= base_url('database') ?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Database</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('network')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Network</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('category')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Category</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('operating_software')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Operating Software</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('deployment')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Deployment</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('operational_hour')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Operational Hour</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('operational_day')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Operational Day</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-server"></i>
              <p>Infra <i class="right fas fa-angle-left"></i></p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
				<a href="<?= base_url('server')?>" class="nav-link">
					<i class="far fa-circle nav-icon"></i>
					<p>Infra Server</p>
				</a>
			  </li>
            </ul>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-calendar-alt"></i>
              <p>Holiday <i class="right fas fa-angle-left"></i></p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item"><a href="#" class="nav-link"><i class="far fa-circle nav-icon"></i><p>List Holiday</p></a></li>
            </ul>
          </li>

        </ul>
      </nav>
    </div>
  </aside>

  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0" style="color: var(--text-dark); font-weight: 700;">Dashboard Utama</h1>
          </div>
        </div>
      </div>
    </div>

    <section class="content">
      <div class="container-fluid">
        <div class="row">
          
          <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
              <div class="inner">
                <h3><?= $count_os ?></h3>
                <p>Total Software</p>
              </div>
              <div class="icon">
                <i class="fas fa-layer-group"></i>
              </div>
              <a href="<?= base_url('operating_software')?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          
          <div class="col-lg-3 col-6">
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?= $count_database ?></h3>
                <p>Total Database</p>
              </div>
              <div class="icon">
                <i class="fas fa-database"></i>
              </div>
              <a href="<?= base_url('database')?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          
          <div class="col-lg-3 col-6">
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?= $count_network ?></h3>
                <p>Total Network</p>
              </div>
              <div class="icon">
                <i class="fas fa-network-wired"></i>
              </div>
              <a href="<?= base_url('network')?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
		  
		  <div class="col-lg-3 col-6">
            <div class="small-box bg-success">
              <div class="inner">
                <h3>99.9<sup style="font-size: 20px">%</sup></h3>
                <p>Achieved SLA</p>
              </div>
              <div class="icon">
                <i class="fas fa-bullseye"></i>
              </div>
              <a href="<?= base_url('server')?>" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>

        </div>

        <div class="row">
          
          <div class="col-lg-7 connectedSortable">
            <div class="card" style="border-top: 3px solid var(--theme-yellow-primary);">
              <div class="card-header">
				  <h3 class="card-title">
					<i class="fas fa-chart-line mr-1"></i>
					SLA Performance (Bulanan)
				  </h3>
				</div>
              <div class="card-body">
                <div class="chart">
                  <canvas id="lineChart" style="min-height: 270px; height: 270px; max-height: 270px; max-width: 100%;"></canvas>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-5 connectedSortable">
            <div class="card" style="border-top: 3px solid var(--theme-yellow-primary);">
              <div class="card-header">
				  <h3 class="card-title">
					<i class="fas fa-server mr-1"></i>
					Server SLA
				  </h3>
				</div>
              <div class="card-body p-0">
                <div class="table-responsive">
                  <table class="table table-striped table-valign-middle">
                    <thead>
                    <tr>
                      <th>Infra Server Name</th>
                      <th>SLA (%)</th>
                    </tr>
                    </thead>
                    <tbody>
					<?php if(!empty($server_sla_list)): ?>
                        <?php foreach($server_sla_list as $infra_server): ?>
                            <?php 
                                // Logic Warna SLA
                                $sla = floatval($infra_server['server_sla']);
                            ?>
                            <tr>
                              <td><?= $infra_server['infra_server_name'] ?></td>
                              <td>
                                  <i class="fas mr-1"></i> <?= $infra_server['server_sla'] ?>%
                              </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="text-center">No Data Available</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

        </div>
        
      </div>
    </section>
  </div>

  <footer class="main-footer">
    <strong>Copyright &copy; 2025 <a href="#" style="color: var(--theme-yellow-hover);">PT Bank CIMB Niaga Tbk</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.2.0
    </div>
  </footer>
</div>

<div id="loadingOverlay">
    <svg class="spinner-svg" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <filter id="spinner-gF00">
                <feGaussianBlur in="SourceGraphic" stdDeviation="1.5" result="y"/>
                <feColorMatrix in="y" mode="matrix" values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 18 -7" result="z"/>
                <feBlend in="SourceGraphic" in2="z"/>
            </filter>
        </defs>
        <g filter="url(#spinner-gF00)">
            <circle cx="4" cy="12" r="3">
                <animate attributeName="cx" calcMode="spline" dur="0.75s" values="4;9;4" keySplines=".56,.52,.17,.98;.56,.52,.17,.98" repeatCount="indefinite"/>
                <animate attributeName="r" calcMode="spline" dur="0.75s" values="3;8;3" keySplines=".56,.52,.17,.98;.56,.52,.17,.98" repeatCount="indefinite"/>
            </circle>
            <circle cx="15" cy="12" r="8">
                <animate attributeName="cx" calcMode="spline" dur="0.75s" values="15;20;15" keySplines=".56,.52,.17,.98;.56,.52,.17,.98" repeatCount="indefinite"/>
                <animate attributeName="r" calcMode="spline" dur="0.75s" values="8;3;8" keySplines=".56,.52,.17,.98;.56,.52,.17,.98" repeatCount="indefinite"/>
            </circle>
        </g>
    </svg>
    <div class="loading-text">Logging out...</div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script> 
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.26.17/dist/sweetalert2.all.min.js"></script>

<script>
    // ==========================================
    // 1. Persiapan Variabel Global untuk Chart
    // ==========================================
    var lineChart; // Variabel ini ditaruh luar agar bisa diakses oleh fungsi dark mode

    // Fungsi untuk mengubah warna teks chart (Hitam <-> Putih)
    function updateChartTheme(isDark) {
        if (!lineChart) return; // Cegah error jika chart belum jadi

        // Tentukan warna
        var textColor = isDark ? '#ffffff' : '#333333'; // Putih jika dark, Hitam jika light
        var gridColor = isDark ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';

        // Update properti chart
        lineChart.options.scales.x.ticks.color = textColor;
        lineChart.options.scales.y.ticks.color = textColor;
        lineChart.options.scales.y.grid.color = gridColor;
        
        // Update warna Legenda (Tulisan "SLA (%)")
        if (lineChart.options.plugins && lineChart.options.plugins.legend) {
            lineChart.options.plugins.legend.labels.color = textColor;
        }

        // Render ulang chart
        lineChart.update();
    }

    // ==========================================
    // 2. Script Dark Mode & Logout
    // ==========================================
    // --- 1. Script Dark Mode (Versi Universal) ---
    const toggleBtn = document.getElementById('darkModeBtn');
    const body = document.body;
    // Cek dulu apakah tombol ada (untuk menghindari error di halaman tanpa navbar)
    const icon = toggleBtn ? toggleBtn.querySelector('i') : null;

    // Fungsi ganti icon
    function updateIcon(isDark) {
        if (!icon) return;
        if (isDark) {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun'); 
        } else {
            icon.classList.remove('fa-sun');
            icon.classList.add('fa-moon'); 
        }
    }

    // Cek status saat load
    if (localStorage.getItem('theme') === 'dark') {
        if(!body.classList.contains('dark-mode')){
            body.classList.add('dark-mode');
        }
        updateIcon(true);
    }

    // Event Listener Klik
    if(toggleBtn) {
        toggleBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            body.classList.toggle('dark-mode');
            const isDark = body.classList.contains('dark-mode');
            
            // Simpan & Update Icon
            if (isDark) {
                localStorage.setItem('theme', 'dark');
                updateIcon(true);
            } else {
                localStorage.setItem('theme', 'light');
                updateIcon(false);
            }

            // --- PERUBAHAN PENTING DISINI ---
            // Cek dulu: Apakah fungsi updateChartTheme SUDAH DIBUAT di halaman ini?
            // Jika halaman ini punya grafik (Dashboard), maka jalankan.
            // Jika halaman ini tidak punya grafik (Database), maka LEWATI agar tidak error.
            if (typeof updateChartTheme === 'function') {
                updateChartTheme(isDark);
            }
        });
    }

    // Script Logout
    const logoutBtn = document.getElementById('logoutLink');
    const overlay = document.getElementById('loadingOverlay');

    if(logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault(); 
            const urlLogout = this.getAttribute('href');

            Swal.fire({
                title: 'Berhasil Logout!',
                text: 'Anda akan keluar dari sistem',
                icon: 'success',
                showConfirmButton: true,
                confirmButtonText: 'OK',
                customClass: {
                    confirmButton: 'btn-theme-gradient' 
                }
            }).then((result) => {
                if (result.isConfirmed || result.isDismissed) {
                    overlay.style.display = 'flex';
                    window.location.href = urlLogout;
                }
            });
        });
    }

    // ==========================================
    // 3. Script Inisialisasi Grafik Line Chart
    // ==========================================
    $(function () {
      var ctx = document.getElementById('lineChart').getContext('2d');
      
      // Cek apakah saat halaman dibuka sudah dark mode?
      var isDarkInit = document.body.classList.contains('dark-mode');
      var initTextColor = isDarkInit ? '#ffffff' : '#333333';
      var initGridColor = isDarkInit ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';

      // Simpan ke variabel global 'lineChart' (bukan var lokal)
      lineChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
          datasets: [
            {
              label: 'SLA (%)',
              backgroundColor: 'rgba(251, 197, 49, 0.2)', 
              borderColor: '#fbc531', 
              pointRadius: 3,
              pointBackgroundColor: '#fbc531',
              pointBorderColor: '#fbc531',
              pointHoverRadius: 5,
              pointHoverBackgroundColor: '#fbc531',
              pointHoverBorderColor: '#fbc531',
              data: [98.5, 99.0, 99.2, 99.1, 99.5, 99.8, 99.9],
              fill: true
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              grid: { display: false },
              ticks: {
                  color: initTextColor // Set warna awal X
              }
            },
            y: {
              beginAtZero: false,
              min: 95,
              max: 100,
              grid: { 
                  borderDash: [2, 2],
                  color: initGridColor // Set warna grid awal
              },
              ticks: {
                  color: initTextColor // Set warna awal Y
              }
            }
          },
          plugins: {
            legend: { 
                display: true,
                labels: {
                    color: initTextColor // Set warna legenda awal
                }
            }
          }
        }
      });
    });
</script>

</body>
</html>