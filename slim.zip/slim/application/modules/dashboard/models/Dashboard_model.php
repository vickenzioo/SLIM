<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

    public function get_server_sla_data() {
        // Select specific columns from the table
        $this->db->select('infra_server_id, infra_server_name, server_sla');
        return $this->db->get('tbl_infra_server')->result_array();
    }

}