<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        
        $this->load->library('session');
        $this->load->model('Dashboard_model'); // Asumsi ini ada di module Dashboard sendiri

        $this->load->model('database/Database_model'); 
        $this->load->model('network/Network_model');
        $this->load->model('operating_software/Operating_Software_model');
        $this->load->model('server/Server_model'); 

        // Cek Login
        if (!$this->session->userdata('email')) {
             redirect('auth');
        }
    }

    public function index() {

        $data['server_sla_list'] = $this->Dashboard_model->get_server_sla_data();
        
        $data['user'] = $this->session->userdata('email');

        $data['count_os'] = $this->Operating_Software_model->count_all_operating_softwares();
        $data['count_database'] = $this->Database_model->count_all_databases();
        $data['count_network'] = $this->Network_model->count_all_networks();
        $data['count_sla'] = $this->Server_model->count_all_infra_servers();

        // Load View dengan data lengkap
        $this->load->view('dashboard_view', $data); 
    }

    public function logout() {
        $this->session->sess_destroy();
        redirect('auth');
    }
}