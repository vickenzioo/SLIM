<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Operating_Software_model extends CI_Model {

    public function get_all_operating_softwares($keyword = null) {
        if($keyword) {
            $this->db->like('operating_software_name', $keyword);
        }
        return $this->db->get('tbl_operating_software')->result_array();
    }

    public function insert_operating_software($data) {
        return $this->db->insert('tbl_operating_software', $data);
    }

    public function update_operating_software($id, $data) {
        $this->db->where('operating_software_id', $id);
        return $this->db->update('tbl_operating_software', $data);
    }

    public function delete_operating_software($id) {
        $this->db->where('operating_software_id', $id);
        return $this->db->delete('tbl_operating_software');
    }
	
	public function check_duplicate_software($name, $id = null) {

        $this->db->where('operating_software_name', $name);

        if($id) {
            $this->db->where('operating_software_id !=', $id);
        }

        $query = $this->db->get('tbl_operating_software');

        return $query->num_rows() > 0;
    }
	
	public function count_all_operating_softwares($keyword = null) {
        if($keyword) {
            $this->db->like('operating_software_name', $keyword);
        }
        return $this->db->count_all_results('tbl_operating_software');
    }
	
	public function get_operating_softwares_paginated($limit, $start, $keyword = null) {
        if($keyword) {
            $this->db->like('operating_software_name', $keyword);
        }
        // Opsional: Urutkan dari yang terbaru
        $this->db->order_by('operating_software_id', 'ASC'); 
        return $this->db->get('tbl_operating_software', $limit, $start)->result_array();
    }
}