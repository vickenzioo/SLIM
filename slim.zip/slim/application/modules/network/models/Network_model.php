<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Network_model extends CI_Model {

    public function get_all_networks($keyword = null) {
        if($keyword) {
            $this->db->like('network_name', $keyword);
        }
        return $this->db->get('tbl_network')->result_array();
    }

    public function insert_network($data) {
        return $this->db->insert('tbl_network', $data);
    }

    public function update_network($id, $data) {
        $this->db->where('network_id', $id);
        return $this->db->update('tbl_network', $data);
    }

    public function delete_network($id) {
        $this->db->where('network_id', $id);
        return $this->db->delete('tbl_network');
    }
	
	public function check_duplicate_network($name, $id = null) {

        $this->db->where('network_name', $name);

        if($id) {
            $this->db->where('network_id !=', $id);
        }

        $query = $this->db->get('tbl_network');

        return $query->num_rows() > 0;
    }
	
	public function count_all_networks($keyword = null) {
        if($keyword) {
            $this->db->like('network_name', $keyword);
        }
        return $this->db->count_all_results('tbl_network');
    }
	
	public function get_networks_paginated($limit, $start, $keyword = null) {
        if($keyword) {
            $this->db->like('network_name', $keyword);
        }
        // Opsional: Urutkan dari yang terbaru
        $this->db->order_by('network_id', 'ASC'); 
        return $this->db->get('tbl_network', $limit, $start)->result_array();
    }
}