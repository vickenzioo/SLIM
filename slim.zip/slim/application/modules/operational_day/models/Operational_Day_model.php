<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Operational_Day_model extends CI_Model {

    public function get_operational_all_days($keyword = null) {
        if($keyword) {
            $this->db->group_start();
			$this->db->like('start_day', $keyword);
			$this->db->or_like('end_day', $keyword);
			$this->db->or_like('total_day', $keyword);
			$this->db->group_end();
        }
        return $this->db->get('tbl_operational_day')->result_array();
    }

    public function insert_operational_day($data) {
        return $this->db->insert('tbl_operational_day', $data);
    }

    public function update_operational_day($id, $data) {
        $this->db->where('operational_day_id', $id);
        return $this->db->update('tbl_operational_day', $data);
    }

    public function delete_operational_day($id) {
        $this->db->where('operational_day_id', $id);
        return $this->db->delete('tbl_operational_day');
    }
	
	public function check_duplicate_day($start_day, $end_day, $id = null) {
        // Cek kondisi 2 kolom harus sama persis (AND)
        $this->db->where('start_day', $start_day);
        $this->db->where('end_day', $end_day);

        // Jika sedang Edit, kecualikan data milik sendiri
        if($id) {
            $this->db->where('operational_day_id !=', $id);
        }

        $query = $this->db->get('tbl_operational_day');

        // Kembalikan TRUE jika ada data kembar
        return $query->num_rows() > 0;
    }
	
	public function count_all_operational_days($keyword = null) {
        if($keyword) {
            $this->db->group_start(); // Kurung buka query (agar logika OR tidak bocor)
            $this->db->like('start_day', $keyword);
            $this->db->or_like('end_day', $keyword);
			$this->db->or_like('total_day', $keyword);
            $this->db->group_end(); // Kurung tutup
        }
        return $this->db->count_all_results('tbl_operational_day');
    }

    // 2. Fungsi Ambil Data Per Halaman (Ada Limit & Start)
    public function get_operational_days_paginated($limit, $start, $keyword = null) {
        if($keyword) {
            $this->db->group_start();
            $this->db->like('start_day', $keyword);
            $this->db->or_like('end_day', $keyword);
			$this->db->or_like('total_day', $keyword);
            $this->db->group_end();
        }
        
        // Urutkan dari yang terbaru (Opsional, tapi disarankan)
        $this->db->order_by('operational_day_id', 'ASC'); 
        
        // Perhatikan parameter ke-2 dan ke-3: Tabel, Limit, Start
        return $this->db->get('tbl_operational_day', $limit, $start)->result_array();
    }
}