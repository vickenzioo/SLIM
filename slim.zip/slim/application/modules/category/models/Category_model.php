<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category_model extends CI_Model {

    public function get_all_categorys($keyword = null) {
        if($keyword) {
			$this->db->group_start();
            $this->db->like('category_name', $keyword);
			$this->db->or_like('standard_category', $keyword);
			$this->db->group_end();
        }
        return $this->db->get('tbl_category')->result_array();
    }

    public function insert_category($data) {
        return $this->db->insert('tbl_category', $data);
    }

    public function update_category($id, $data) {
        $this->db->where('category_id', $id);
        return $this->db->update('tbl_category', $data);
    }

    public function delete_category($id) {
        $this->db->where('category_id', $id);
        return $this->db->delete('tbl_category');
    }
	
	public function check_duplicate_category($name, $id = null) {

        $this->db->where('category_name', $name);

        if($id) {
            $this->db->where('category_id !=', $id);
        }

        $query = $this->db->get('tbl_category');

        return $query->num_rows() > 0;
    }
	
	public function count_all_categorys($keyword = null) {
        if($keyword) {
            $this->db->group_start();
            $this->db->like('category_name', $keyword);
			$this->db->or_like('standard_category', $keyword);
			$this->db->group_end();
        }
        return $this->db->count_all_results('tbl_category');
    }
	
	public function get_categorys_paginated($limit, $start, $keyword = null) {
        if($keyword) {
            $this->db->group_start();
            $this->db->like('category_name', $keyword);
			$this->db->or_like('standard_category', $keyword);
			$this->db->group_end();
        }
        // Opsional: Urutkan dari yang terbaru
        $this->db->order_by('category_id', 'ASC'); 
        return $this->db->get('tbl_category', $limit, $start)->result_array();
    }
}