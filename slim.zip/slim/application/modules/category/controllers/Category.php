<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

    public function __construct() {
        parent::__construct();

        // Cek Login
        if (!$this->session->userdata('email')) {
             redirect('auth');
        }

        // Load Model
        $this->load->model('Category_model');
    }

    public function index() {
        // 1. Load Library Pagination
        $this->load->library('pagination');

        // 2. Ambil Keyword Pencarian
        $keyword = $this->input->get('keyword');

        // 3. Konfigurasi Pagination
        $config['base_url'] = base_url('category/index');
        
        // Ambil total data dari Model yang baru ditambahkan
        $config['total_rows'] = $this->Category_model->count_all_categorys($keyword);
        
        $config['per_page'] = 5; // Jumlah data per halaman
        
        // PENTING: Agar pencarian tidak hilang saat pindah halaman
        $config['enable_query_strings'] = TRUE;
        $config['page_query_string'] = TRUE;
        $config['query_string_segment'] = 'per_page';
        $config['reuse_query_string'] = TRUE;

        // --- STYLE BOOTSTRAP 4 (Agar tampilan rapi & kuning) ---
        $config['full_tag_open']    = '<ul class="pagination pagination-sm m-0 float-right">';
        $config['full_tag_close']   = '</ul>';
        
        $config['first_link']       = 'First';
        $config['first_tag_open']   = '<li class="page-item">';
        $config['first_tag_close']  = '</li>';
        
        $config['last_link']        = 'Last';
        $config['last_tag_open']    = '<li class="page-item">';
        $config['last_tag_close']   = '</li>';
        
        $config['next_link']        = '&raquo;';
        $config['next_tag_open']    = '<li class="page-item">';
        $config['next_tag_close']   = '</li>';
        
        $config['prev_link']        = '&laquo;';
        $config['prev_tag_open']    = '<li class="page-item">';
        $config['prev_tag_close']   = '</li>';
        
        $config['cur_tag_open']     = '<li class="page-item active"><a class="page-link" href="#">';
        $config['cur_tag_close']    = '</a></li>';
        
        $config['num_tag_open']     = '<li class="page-item">';
        $config['num_tag_close']    = '</li>';
        
        // Tambahkan class atribut untuk link
        $config['attributes']       = array('class' => 'page-link');

        // 4. Inisialisasi Config
        $this->pagination->initialize($config);

        // 5. Ambil Data Sesuai Halaman (Start Index)
        $start = $this->input->get('per_page');
        
        // Panggil fungsi model paginated
        $data['categorys'] = $this->Category_model->get_categorys_paginated($config['per_page'], $start, $keyword);
        
        // 6. Kirim data ke View
        $data['keyword'] = $keyword;
        $data['pagination'] = $this->pagination->create_links(); // Link tombol halaman
        $data['total_rows'] = $config['total_rows']; // Untuk info total data

        $this->load->view('category_view', $data);
    }

    public function save() {
        $id = $this->security->xss_clean($this->input->post('category_id'));
        $name = $this->security->xss_clean($this->input->post('category_name'));
        $category = $this->security->xss_clean($this->input->post('standard_category'));
		
		if ($this->Category_model->check_duplicate_category($name, $id)) {
            // Jika duplikat, set pesan error
            $this->session->set_flashdata('error', 'Nama Category "'. $name .'" sudah ada! Gagal menyimpan.');
            
            // Kembalikan ke halaman index
            redirect('category');
            
            // Hentikan eksekusi script agar tidak lanjut menyimpan ke bawah
            return; 
        }

		if (!is_numeric($category)) {
            $this->session->set_flashdata('error', 'Standard Category harus berupa angka!');
            redirect('category');
            return; // Hentikan proses
        }

		$createdBy = $this->session->userdata('user_id');

        if ($id) {
            // Edit Mode
			$data = [
			'category_name' => $name, 
			'standard_category' => $category,
			'modified_by' => $createdBy,
			'modified_at' => date("Y-m-d")
			];
			
            $this->Category_model->update_category($id, $data);
            $this->session->set_flashdata('success', 'Data Category berhasil diperbarui');
        } else {
            // Add Mode
			$data = [
			'category_name' => $name, 
			'standard_category' => $category,
			'created_by' => $createdBy,
			'created_at' => date("Y-m-d")
			];
            
			$this->Category_model->insert_category($data);
            $this->session->set_flashdata('success', 'Data Category berhasil ditambahkan');
        }

        redirect('category');
    }

    public function delete($id) {
        $this->Category_model->delete_category($id);
        $this->session->set_flashdata('success', 'Data Category berhasil dihapus');
        redirect('category');
    }
	
	public function export() {
    // 1. Ambil data dari model
    $data['categorys'] = $this->Category_model->get_all_categorys();

    // 2. SET HEADER (INI YANG MEMBUAT TIDAK PINDAH HALAMAN)
    // 'attachment' memaksa browser untuk download, bukan membuka halaman baru
    header("Content-type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=Category_".date('Y-m-d').".xls");
    header("Pragma: no-cache");
    header("Expires: 0");

    // 3. Load view isi data
    $this->load->view('category_export', $data);
	}
}