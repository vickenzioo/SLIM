<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Deployment_model extends CI_Model {

    public function get_all_Deployments($keyword = null) {
        if($keyword) {
            $this->db->group_start();
			$this->db->like('deployment_model', $keyword);
			$this->db->or_like('deployment_provider', $keyword);
			$this->db->or_like('main_deployment_site', $keyword);
			$this->db->group_end();
        }
        return $this->db->get('tbl_deployment')->result_array();
    }

    public function insert_Deployment($data) {
        return $this->db->insert('tbl_Deployment', $data);
    }

    public function update_Deployment($id, $data) {
        $this->db->where('Deployment_id', $id);
        return $this->db->update('tbl_Deployment', $data);
    }

    public function delete_Deployment($id) {
        $this->db->where('Deployment_id', $id);
        return $this->db->delete('tbl_Deployment');
    }
	
	public function check_duplicate_deployment($name, $provider, $site, $id = null) {
        // Cek kondisi 3 kolom harus sama persis (AND)
        $this->db->where('deployment_model', $name);
        $this->db->where('deployment_provider', $provider);
        $this->db->where('main_deployment_site', $site);

        // Jika sedang Edit, kecualikan data milik sendiri
        if($id) {
            $this->db->where('deployment_id !=', $id);
        }

        $query = $this->db->get('tbl_deployment');

        // Kembalikan TRUE jika ada data kembar
        return $query->num_rows() > 0;
    }
	
	public function count_all_deployments($keyword = null) {
        if($keyword) {
            $this->db->group_start(); // Kurung buka query (agar logika OR tidak bocor)
            $this->db->like('deployment_model', $keyword);
            $this->db->or_like('deployment_provider', $keyword);
            $this->db->or_like('main_deployment_site', $keyword);
            $this->db->group_end(); // Kurung tutup
        }
        return $this->db->count_all_results('tbl_deployment');
    }

    // 2. Fungsi Ambil Data Per Halaman (Ada Limit & Start)
    public function get_deployments_paginated($limit, $start, $keyword = null) {
        if($keyword) {
            $this->db->group_start();
            $this->db->like('deployment_model', $keyword);
            $this->db->or_like('deployment_provider', $keyword);
            $this->db->or_like('main_deployment_site', $keyword);
            $this->db->group_end();
        }
        
        // Urutkan dari yang terbaru (Opsional, tapi disarankan)
        $this->db->order_by('deployment_id', 'ASC'); 
        
        // Perhatikan parameter ke-2 dan ke-3: Tabel, Limit, Start
        return $this->db->get('tbl_deployment', $limit, $start)->result_array();
    }
}