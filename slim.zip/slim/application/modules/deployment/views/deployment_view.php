<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SLIM | Deployment</title>

  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@800;900&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
  
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
  <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/1864/1864497.png" type="image/png">
  <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.26.17/dist/sweetalert2.min.css" rel="stylesheet">
  <link rel="stylesheet" href="<?= base_url('assets/dist/css/slim/dashboard.css'); ?>">
  
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body class="hold-transition sidebar-mini layout-fixed">

<script>
    if (localStorage.getItem('theme') === 'dark') {
        document.body.classList.add('dark-mode');
    }
</script>

<div class="wrapper">

  <nav class="main-header navbar navbar-expand navbar-white navbar-light" style="border-bottom: 3px solid var(--theme-yellow-primary);">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?= base_url('dashboard') ?>" class="nav-link breadcrumb-home">Home</a>
      </li>
    </ul>

    <ul class="navbar-nav ml-auto">
	  <li class="nav-item">
         <a class="nav-link" href="#" role="button" id="darkModeBtn" title="Ganti Mode">
           <i class="fas fa-moon"></i>
         </a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="far fa-user mr-2"></i>
          <span class="font-weight-bold">
            <?= $this->session->userdata('username') ? $this->session->userdata('username') : 'User'; ?>
          </span>
          <i class="fas fa-caret-down ml-1"></i>
        </a>
        
        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
          <div class="dropdown-divider"></div>
          
          <a href="#" class="dropdown-item">
            <i class="fas fa-user-edit mr-2 text-warning"></i> Edit Profile
          </a>
          
          <div class="dropdown-divider"></div>
          
          <a href="<?= base_url('auth/logout') ?>" class="dropdown-item text-danger" id="logoutLink">
            <i class="fas fa-sign-out-alt mr-2"></i> Logout
          </a>
        </div>
      </li>
    </ul>
  </nav>
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="<?= base_url('dashboard') ?>" class="brand-link">
       <svg width="120" height="40" viewBox="0 0 240 80" xmlns="http://www.w3.org/2000/svg">
            <defs>
                <linearGradient id="textGradientSide" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" style="stop-color:#ffffff;stop-opacity:1" /> 
                    <stop offset="100%" style="stop-color:#dcdcdc;stop-opacity:1" />
                </linearGradient>
                <linearGradient id="goldGradientSide" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style="stop-color:#fbc531;stop-opacity:1" />
                    <stop offset="100%" style="stop-color:#e1b12c;stop-opacity:1" />
                </linearGradient>
            </defs>
            <text x="50%" y="55" font-family="'Montserrat', sans-serif" font-weight="900" font-style="italic" font-size="65" fill="url(#textGradientSide)" text-anchor="middle" letter-spacing="-2">SLIM</text>
            <circle cx="195" cy="55" r="6" fill="#fbc531" />
            <path d="M 40 70 L 200 70" stroke="url(#goldGradientSide)" stroke-width="6" stroke-linecap="round" />
        </svg>
    </a>

    <div class="sidebar">

      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          
          <li class="nav-item">
            <a href="<?= base_url('dashboard')?>" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>Dashboard</p>
            </a>
          </li>

          <li class="nav-item menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-cubes"></i>
              <p>Apps <i class="right fas fa-angle-left"></i></p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?= base_url('database')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Database</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('network')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Network</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('category')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Category</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('operating_software')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Operating Software</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('deployment')?>" class="nav-link active">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Deployment</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('operational_hour')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Operational Hour</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?= base_url('operational_day')?>" class="nav-link">
                    <i class="far fa-circle nav-icon"></i>
                    <p>Operational Day</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-server"></i>
              <p>Infra <i class="right fas fa-angle-left"></i></p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
				<a href="<?= base_url('server')?>" class="nav-link">
					<i class="far fa-circle nav-icon"></i>
					<p>Infra Server</p>
				</a>
			  </li>
            </ul>
          </li>

          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-calendar-alt"></i>
              <p>Holiday <i class="right fas fa-angle-left"></i></p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item"><a href="#" class="nav-link"><i class="far fa-circle nav-icon"></i><p>List Holiday</p></a></li>
            </ul>
          </li>

        </ul>
      </nav>
    </div>
  </aside>

  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0" style="color: var(--text-dark); font-weight: 700;">Deployment Management</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item">
				<a href="<?= base_url('dashboard')?>" class="breadcrumb-home">Home</a></li>
              <li class="breadcrumb-item active">Deployment</li>
            </ol>
          </div>
        </div>
      </div>
    </div>

    <section class="content">
      <div class="container-fluid">
        
        <div class="card" style="border-top: 3px solid var(--theme-yellow-primary);">
            <div class="card-header" style="background-color: #fff;">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <button class="btn btn-theme-gradient btn-sm" onclick="clearForm()">
                            <i class="fas fa-plus mr-1"></i> Add
                        </button>
						<button class="btn btn-theme-gradient btn-sm ml-1" onclick="confirmExport()">
                            <i class="fas fa-file-export mr-1"></i> Export
                        </button>
                    </div>
                    <div class="col-md-6">
                        <form action="<?= base_url('Deployment') ?>" method="get">
                            <div class="input-group">
                                <input type="text" name="keyword" class="form-control" placeholder="Search Deployment Name..." value="<?= isset($keyword) ? $keyword : '' ?>">
                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="card-body">
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                        <tr class="bg-info">
							<th style="width: 50px; text-align: center; color: var(--text-dark);">No</th>
                            <th style="color: var(--text-dark);">Deployment Model</th>
							<th style="color: var(--text-dark);">Deployment Provider</th>
							<th style="color: var(--text-dark);">Main Deployment Site</th>
                            <th style="width: 200px; text-align: center; color: var(--text-dark);">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(!empty($deployments)): ?>
                            <?php 
                                $start = $this->input->get('per_page');
                                $no = $start ? $start + 1 : 1; 
                            ?>
                            <?php foreach($deployments as $db): ?>
                            <tr>
                                <td class="text-center align-middle"><?= $no++ ?></td>
                                <td class="align-middle"><?= $db['deployment_model'] ?></td>
                                <td class="align-middle"><?= $db['deployment_provider'] ?></td>
                                <td class="align-middle"><?= $db['main_deployment_site'] ?></td>
                                <td class="text-center align-middle">
                                    <button class="btn btn-sm btn-action-yellow"
                                            onclick="editDep(<?= $db['deployment_id'] ?>, '<?= $db['deployment_model'] ?>', '<?= $db['deployment_provider'] ?>', '<?= $db['main_deployment_site'] ?>')"
											title="Edit Data">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    
                                    <a href="#" onclick="confirmDelete('<?= base_url('deployment/delete/'.$db['deployment_id']) ?>')" 
                                       class="btn btn-sm btn-action-red ml-1"
									   title="Hapus Data">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">No Data Found</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="card-footer clearfix bg-white">
                <div class="float-right">
                    <?php 
                        // 1. Cek apakah link pagination dari controller ada isinya?
                        if(!empty($pagination)) {
                            // Jika ada (berarti lebih dari 1 halaman), tampilkan normal
                            echo $pagination;
                        } 
                        // 2. Jika kosong TAPI datanya ada (berarti cuma 1 halaman)
                        elseif(isset($total_rows) && $total_rows > 0) {
                            // Tampilkan manual tombol angka 1
                            echo '<ul class="pagination pagination-sm m-0 float-right">';
                            echo '<li class="page-item active"><a class="page-link" href="#">1</a></li>';
                            echo '</ul>';
                        }
                        // 3. Jika total_rows 0, biarkan kosong
                    ?>
                </div>
                <div class="float-left">
                    <small class="text-muted">
                        Total Data: <?= isset($total_rows) ? $total_rows : 0 ?>
                    </small>
                </div>
            </div>

      </div>
    </section>
  </div>

  <footer class="main-footer">
    <strong>Copyright &copy; 2025 <a href="#" style="color: var(--theme-yellow-hover);">PT Bank CIMB Niaga Tbk</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.2.0
    </div>
  </footer>
</div>

<div class="modal fade" id="modalDeployment" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background: linear-gradient(135deg, var(--theme-bg-yellow-light) 0%, var(--theme-bg-yellow-dark) 100%); color: var(--text-dark);">
        <h5 class="modal-title" id="modalTitle">Add Deployment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?= base_url('deployment/save') ?>" method="post">
          <div class="modal-body">
            <input type="hidden" name="deployment_id" id="deployment_id">
            <div class="form-group">
                <label>Deployment Model</label>
                <input type="text" name="deployment_model" id="deployment_model" class="form-control" required placeholder="Enter Deployment Model">
            </div>
			<div class="form-group">
                <label>Deployment Provider</label>
                <input type="text" name="deployment_provider" id="deployment_provider" class="form-control" required placeholder="Enter Deployment Provider">
            </div>
			<div class="form-group">	
				<label>Main Deployment Site</label>
                <input type="text" name="main_deployment_site" id="main_deployment_site" class="form-control" required placeholder="Enter Main Deployment Site">
			</div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary btn-save-custom">
				Save Changes
			</button>
          </div>
      </form>
    </div>
  </div>
</div>
<div id="loadingOverlay">
    <svg class="spinner-svg" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
        <defs>
            <filter id="spinner-gF00">
                <feGaussianBlur in="SourceGraphic" stdDeviation="1.5" result="y"/>
                <feColorMatrix in="y" mode="matrix" values="1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 18 -7" result="z"/>
                <feBlend in="SourceGraphic" in2="z"/>
            </filter>
        </defs>
        <g filter="url(#spinner-gF00)">
            <circle cx="4" cy="12" r="3">
                <animate attributeName="cx" calcMode="spline" dur="0.75s" values="4;9;4" keySplines=".56,.52,.17,.98;.56,.52,.17,.98" repeatCount="indefinite"/>
                <animate attributeName="r" calcMode="spline" dur="0.75s" values="3;8;3" keySplines=".56,.52,.17,.98;.56,.52,.17,.98" repeatCount="indefinite"/>
            </circle>
            <circle cx="15" cy="12" r="8">
                <animate attributeName="cx" calcMode="spline" dur="0.75s" values="15;20;15" keySplines=".56,.52,.17,.98;.56,.52,.17,.98" repeatCount="indefinite"/>
                <animate attributeName="r" calcMode="spline" dur="0.75s" values="8;3;8" keySplines=".56,.52,.17,.98;.56,.52,.17,.98" repeatCount="indefinite"/>
            </circle>
        </g>
    </svg>
    <div class="loading-text">Logging out...</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.26.17/dist/sweetalert2.all.min.js"></script>

<script>
    // Fungsi Buka Modal Tambah
    function clearForm() {
        $('#modalTitle').text('Add Deployment');
        $('#deployment_id').val('');
        $('#deployment_model').val('');
        $('#deployment_provider').val('');
		$('#main_deployment_site').val('');
        $('#modalDeployment').modal('show'); 
    }

    // Fungsi Buka Modal Edit
    function editDep(id, name, provider, site) {
        $('#modalTitle').text('Edit Deployment');
        $('#deployment_id').val(id);
        $('#deployment_model').val(name);
        $('#deployment_provider').val(provider);
		$('#main_deployment_site').val(site);
        $('#modalDeployment').modal('show'); 
    }
	
	function confirmExport() {
        Swal.fire({
            title: 'Export to Excel?',
            text: "File akan otomatis diunduh.",
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Yes, export!',
            cancelButtonText: 'Cancel',
            buttonsStyling: false,
            customClass: {
                confirmButton: 'btn btn-save-custom px-4 mx-2', 
                cancelButton: 'btn btn-secondary px-4 mx-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                // Tampilkan notifikasi kecil bahwa download sedang berjalan
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true
                });
                
                Toast.fire({
                    icon: 'success',
                    title: 'Downloading file...'
                });

                // PERINTAH DOWNLOAD
                // Browser akan mendeteksi header 'attachment' dari controller
                // sehingga halaman TIDAK AKAN BERPINDAH, file langsung turun.
                window.location.href = "<?= base_url('deployment/export') ?>";
            }
        })
    }

    // Fungsi Konfirmasi Hapus
    function confirmDelete(url) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel',
            buttonsStyling: false, 
            customClass: {
                confirmButton: 'btn btn-danger px-4 mx-2', 
                cancelButton: 'btn btn-secondary px-4 mx-2'
            }
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = url;
            }
        })
    }

    // Flashdata Success
    <?php if($this->session->flashdata('success')): ?>
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: '<?= $this->session->flashdata('success') ?>',
            confirmButtonText: 'OK',
            buttonsStyling: false,
            customClass: { confirmButton: 'btn btn-theme-gradient px-4' }
        });
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    // 2. Flashdata Error (Jika ada duplikat nama database) -> INI YANG DITAMBAHKAN
    <?php if($this->session->flashdata('error')): ?>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: '<?= $this->session->flashdata('error') ?>',
            confirmButtonText: 'OK',
            buttonsStyling: false,
            // Tombol warna merah
            customClass: { confirmButton: 'btn btn-danger px-4' } 
        });
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
    
	// --- 1. Script Dark Mode (Versi Universal) ---
    const toggleBtn = document.getElementById('darkModeBtn');
    const body = document.body;
    // Cek dulu apakah tombol ada (untuk menghindari error di halaman tanpa navbar)
    const icon = toggleBtn ? toggleBtn.querySelector('i') : null;

    // Fungsi ganti icon
    function updateIcon(isDark) {
        if (!icon) return;
        if (isDark) {
            icon.classList.remove('fa-moon');
            icon.classList.add('fa-sun'); 
        } else {
            icon.classList.remove('fa-sun');
            icon.classList.add('fa-moon'); 
        }
    }

    // Cek status saat load
    if (localStorage.getItem('theme') === 'dark') {
        if(!body.classList.contains('dark-mode')){
            body.classList.add('dark-mode');
        }
        updateIcon(true);
    }

    // Event Listener Klik
    if(toggleBtn) {
        toggleBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            body.classList.toggle('dark-mode');
            const isDark = body.classList.contains('dark-mode');
            
            // Simpan & Update Icon
            if (isDark) {
                localStorage.setItem('theme', 'dark');
                updateIcon(true);
            } else {
                localStorage.setItem('theme', 'light');
                updateIcon(false);
            }

            // --- PERUBAHAN PENTING DISINI ---
            // Cek dulu: Apakah fungsi updateChartTheme SUDAH DIBUAT di halaman ini?
            // Jika halaman ini punya grafik (Dashboard), maka jalankan.
            // Jika halaman ini tidak punya grafik (Database), maka LEWATI agar tidak error.
            if (typeof updateChartTheme === 'function') {
                updateChartTheme(isDark);
            }
        });
    }
	
    // --- Script Logout ---
    const logoutBtn = document.getElementById('logoutLink');
    const overlay = document.getElementById('loadingOverlay');

    if(logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault(); 
            const urlLogout = this.getAttribute('href');

            Swal.fire({
                title: 'Berhasil Logout!',
                text: 'Anda akan keluar dari sistem',
                icon: 'success',
                showConfirmButton: true,
                confirmButtonText: 'OK',
                customClass: {
                    confirmButton: 'btn-theme-gradient' 
                }
            }).then((result) => {
                if (result.isConfirmed || result.isDismissed) {
                    overlay.style.display = 'flex';
                    window.location.href = urlLogout;
                }
            });
        });
    }
</script>

</body>
</html>