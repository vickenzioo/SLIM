<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Server_model extends CI_Model {

    public function get_all_servers($keyword = null) {
        if($keyword) {
			$this->db->group_start();
            $this->db->like('infra_server_name', $keyword);
			$this->db->or_like('server_sla', $keyword);
			$this->db->group_end();

        }
        return $this->db->get('tbl_server')->result_array();
    }

    public function insert_server($data) {
        return $this->db->insert('tbl_server', $data);
    }

    public function update_server($id, $data) {
        $this->db->where('infra_server_id', $id);
        return $this->db->update('tbl_server', $data);
    }

    public function delete_server($id) {
        $this->db->where('infra_server_id', $id);
        return $this->db->delete('tbl_server');
    }
	
	public function check_duplicate_server($name, $id = null) {

        $this->db->where('infra_server_name', $name);

        if($id) {
            $this->db->where('infra_server_id !=', $id);
        }

        $query = $this->db->get('tbl_server');

        return $query->num_rows() > 0;
    }
	
	public function count_all_infra_servers($keyword = null) {
        if($keyword) {
            $this->db->group_start();
            $this->db->like('infra_server_name', $keyword);
			$this->db->or_like('server_sla', $keyword);
			$this->db->group_end();
        }
        return $this->db->count_all_results('tbl_infra_server');
    }
	
	public function get_infra_servers_paginated($limit, $start, $keyword = null) {
        if($keyword) {
            $this->db->group_start();
            $this->db->like('infra_server_name', $keyword);
			$this->db->or_like('server_sla', $keyword);
			$this->db->group_end();
        }
        // Opsional: Urutkan dari yang terbaru
        $this->db->order_by('infra_server_id', 'ASC'); 
        return $this->db->get('tbl_infra_server', $limit, $start)->result_array();
    }
}